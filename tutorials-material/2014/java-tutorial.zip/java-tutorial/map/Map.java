
public interface Map{

    Integer put(String key, Integer value);

    Integer get(String key);

    Integer remove(String key);

    String[] keySet();

    boolean containsKey(String key);
}
