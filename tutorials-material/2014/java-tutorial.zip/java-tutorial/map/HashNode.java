
public class HashNode{

    int cachedHcv;

    String key;

    Integer value;

    HashNode next;

    HashNode prev;

    public HashNode(String key, Integer value){
        this.cachedHcv = key.hashCode();
        this.key = key;
        this.value = value;
    }

}
