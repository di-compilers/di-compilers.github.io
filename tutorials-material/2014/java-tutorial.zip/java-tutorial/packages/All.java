import packagea.A;
import packageb.B;
import packageb.packageb1.B1;

public class All{

    public static void main(String[] args){
        A.main(null);
        B.main(null);
        B1.main(null);
    }

}
