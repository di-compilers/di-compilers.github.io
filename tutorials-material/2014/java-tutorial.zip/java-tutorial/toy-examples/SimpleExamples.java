

public class SimpleExamples{


    private static void foo(A a1){
        a1.i++;
    }

    private static void dudeWhereIsMySwap(A a1, A a2){
        A tmp = a1;
        a1 = a2;
        a2 = tmp;
    }

    public static void main(String[] args){
        A a = new A();

        System.out.println(a.i);

        foo(a);

        System.out.println(a.i);

        //Let's create one more A
        A aa = new A();

        foo(a);
        foo(aa);

        System.out.println(a.i + " " + aa.i);

        dudeWhereIsMySwap(a, aa);

        System.out.println(a.i + " " + aa.i);
        System.out.println("Wat?");
    }

}


class A {

    int i;

    A(){ i = 1; }
}
