import visitors.*;
import visitables.*;

public class Main{

    public static void main(String[] agrs){
        Animal[] animals = new Animal[2];
        Visitor[] visitors = new Visitor[2];
        animals[0] = new Cat("Buttons");
        animals[1] = new Dog("Azor");
        visitors[0] = new Speak();
        visitors[1] = new Sleep();

        for(int i = 0 ; i < 2 ; ++i)
            for(int j = 0 ; j < 2 ; ++j){
                animals[i].accept(visitors[j]);
                System.out.println();
            }
    }

}
