package visitors;

import visitables.*;

public interface Visitor {

    public void visit(Cat c);

    public void visit(Dog d);

}