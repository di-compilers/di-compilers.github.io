package visitors;

import visitables.*;

public class Sleep implements Visitor {

    public void visit(Cat c){
        System.out.println("I'm a cat.");
        System.out.println("My name is: " + c.getName());
        System.out.println("Goodnight ...");
    }

    public void visit(Dog d){
        System.out.println("I'm a dog.");
        System.out.println("My name is: " + d.getName());
        System.out.println("Goodnight ...");
    }

}
