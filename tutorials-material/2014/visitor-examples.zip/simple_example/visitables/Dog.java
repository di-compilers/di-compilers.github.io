package visitables;

import visitors.Visitor;

public class Dog extends Animal {

    private String name;

    public Dog(String name){
        this.name = name;
    }

    public void accept(Visitor v){
        v.visit(this);
    }

    public String getName(){
        return this.name;
    }

}
