package visitables;

import visitors.Visitor;

public class Cat extends Animal {

    private String name;

    public Cat(String name){
        this.name = name;
    }

    public void accept(Visitor v){
        v.visit(this);
    }

    public String getName(){
        return this.name;
    }


}
