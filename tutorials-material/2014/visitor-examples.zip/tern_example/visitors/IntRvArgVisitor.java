package visitors;

import tree.*;

public interface IntRvArgVisitor{

    public int visit(TernNode tn, int arg);

    public int visit(TernTailAlt1 t1, int arg);

    public int visit(TernTailAlt2 t2, int arg);

}