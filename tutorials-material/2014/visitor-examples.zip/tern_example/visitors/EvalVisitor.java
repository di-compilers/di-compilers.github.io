package visitors;

import tree.*;


public class EvalVisitor extends IntRvArgDfsVisitor {


    public int visit(TernNode tn, int _){
	int cond = tn.number - '0';
	return tn.ternTail.accept(this, cond);
    }

    public int visit(TernTailAlt1 tl1, int cond){
	int thenPrt = tl1.thenPart.accept(this, 0);
	int elsePrt = tl1.elsePart.accept(this, 0);
	return cond != 0 ? thenPrt : elsePrt;
    }

    public int visit(TernTailAlt2 _, int cond){
	return cond;
    }

}