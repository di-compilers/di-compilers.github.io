package visitors;

import tree.*;

public class PrintVisitor extends SimpleDfsVisitor{


    public void visit(TernNode tn){
        System.out.print(tn.number - '0');
        tn.ternTail.accept(this);
    }

    public void visit(TernTailAlt1 tl1){
        System.out.print((char)tl1.qMark);
        tl1.thenPart.accept(this);
        System.out.print((char)tl1.semiC);
        tl1.elsePart.accept(this);
    }

    public void visit(TernTailAlt2 _){

    }

}
