package tree;

import visitors.SimpleVisitor;
import visitors.IntRvArgVisitor;

public class TernTailAlt1 extends TernTailNode {

    public int qMark;

    public TernNode thenPart;

    public int semiC;

    public TernNode elsePart;

    public TernTailAlt1(int qMark, TernNode thenPart, int semiC, TernNode elsePart){
        this.qMark = qMark;
        this.thenPart = thenPart;
        this.semiC = semiC;
        this.elsePart = elsePart;
    }

    public void accept(SimpleVisitor v){
        v.visit(this);
    }

    public int accept(IntRvArgVisitor v, int cond){
        return v.visit(this, cond);
    }

}
