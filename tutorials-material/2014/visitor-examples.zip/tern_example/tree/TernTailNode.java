package tree;

import visitors.SimpleVisitor;
import visitors.IntRvArgVisitor;

public abstract class TernTailNode{

    public abstract void accept(SimpleVisitor v);

    public abstract int accept(IntRvArgVisitor v, int cond);

}
