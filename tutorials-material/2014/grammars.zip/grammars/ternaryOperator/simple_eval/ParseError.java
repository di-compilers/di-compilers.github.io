public class ParseError extends Exception {

    public String getMessage() {
	return "parse errror";
    }
}