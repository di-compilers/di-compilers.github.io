package tree;

public class TernNode {


    private int number;

    private TernTailNode ternTail;

    public TernNode(int number, TernTailNode ternTail){
	this.number = number;
	this.ternTail = ternTail;
    }

    public int eval(){
	return this.ternTail.eval(number - '0');
    }

    public void print(){
	System.out.print(this.number-'0');
	this.ternTail.print();
    }

}
