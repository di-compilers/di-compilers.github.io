package tree;

public abstract class TernTailNode{

    public abstract int eval(int cond);


    public abstract void print();
}