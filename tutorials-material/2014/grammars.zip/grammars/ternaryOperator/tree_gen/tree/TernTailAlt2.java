package tree;

public class TernTailAlt2 extends TernTailNode {


    public int eval(int cond){
	return cond;
    }

    public void print(){
	
    }

}