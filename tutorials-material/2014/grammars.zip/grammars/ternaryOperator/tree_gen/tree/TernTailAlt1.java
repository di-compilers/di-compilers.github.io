package tree;

public class TernTailAlt1 extends TernTailNode {

    private int qMark;

    private TernNode thenPart;

    private int semiC;

    private TernNode elsePart;

    public TernTailAlt1(int qMark, TernNode thenPart, int semiC, TernNode elsePart){
	this.qMark = qMark;
	this.thenPart = thenPart;
	this.semiC = semiC;
	this.elsePart = elsePart;
    }

    public int eval(int cond){
	return cond != 0 ? this.thenPart.eval() : this.elsePart.eval();
    }


    public void print(){
	System.out.print((char)this.qMark);
	this.thenPart.print();
	System.out.print((char)this.semiC);
	this.elsePart.print();
    }
}