Execution instructions:

$ make compile
$ make execute

To cleanup generated files:
$ make clean
