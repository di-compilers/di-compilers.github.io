class StringConstants {
    public String a = "a";
}
