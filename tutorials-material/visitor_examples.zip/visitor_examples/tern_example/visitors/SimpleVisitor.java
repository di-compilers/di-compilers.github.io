package visitors;

import tree.*;

public interface SimpleVisitor{

    public void visit(TernNode tn);

    public void visit(TernTailAlt1 tl1);

    public void visit(TernTailAlt2 tl2);
 
}