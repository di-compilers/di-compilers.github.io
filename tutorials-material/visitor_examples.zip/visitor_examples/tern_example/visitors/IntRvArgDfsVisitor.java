package visitors;

import tree.*;

public class IntRvArgDfsVisitor implements IntRvArgVisitor {

    public int visit(TernNode tn, int arg){
	int rv = 0;
	tn.ternTail.accept(this, arg);
	return rv;
    }

    public int visit(TernTailAlt1 tl1, int arg){
	int rv = 0;
	tl1.thenPart.accept(this, arg);
	tl1.elsePart.accept(this, arg);
	return rv;
    }

    public int visit(TernTailAlt2 tl2, int arg){
	int rv = 0;
	return rv;
    }

}