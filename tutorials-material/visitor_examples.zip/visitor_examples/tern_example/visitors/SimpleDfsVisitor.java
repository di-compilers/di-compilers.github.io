package visitors;

import tree.*;

public class SimpleDfsVisitor implements SimpleVisitor{

    public void visit(TernNode tn){
	tn.ternTail.accept(this);
    }

    public void visit(TernTailAlt1 tl1){
	tl1.thenPart.accept(this);
	tl1.elsePart.accept(this);
    }

    public void visit(TernTailAlt2 tl2){

    }

}