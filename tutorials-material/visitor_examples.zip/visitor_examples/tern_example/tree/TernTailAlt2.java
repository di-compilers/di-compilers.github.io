package tree;

import visitors.SimpleVisitor;
import visitors.IntRvArgVisitor;

public class TernTailAlt2 extends TernTailNode {

    public void accept(SimpleVisitor v){
	v.visit(this);
    }

    public int accept(IntRvArgVisitor v, int arg){
	return v.visit(this, arg);
    }

}
