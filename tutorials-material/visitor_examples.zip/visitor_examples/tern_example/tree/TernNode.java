package tree;

import visitors.SimpleVisitor;
import visitors.IntRvArgVisitor;

public class TernNode {


    public int number;

    public TernTailNode ternTail;

    public TernNode(int number, TernTailNode ternTail){
	this.number = number;
	this.ternTail = ternTail;
    }

    public void accept(SimpleVisitor v){
	v.visit(this);
    }

    public int accept(IntRvArgVisitor v, int arg){
	return v.visit(this, arg);
    }

}
