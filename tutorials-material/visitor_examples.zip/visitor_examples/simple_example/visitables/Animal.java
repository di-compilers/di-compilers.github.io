package visitables;

import visitors.Visitor;

public abstract class Animal {

    public abstract void accept(Visitor v);

}