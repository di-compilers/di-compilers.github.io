package visitors;

import visitables.*;

public class Speak implements Visitor{

    public void visit(Cat c){
	System.out.println(c.getName() + ": meow");
    }


    public void visit(Dog d){
	System.out.println(d.getName() + ": woof");
    }

}